local REQUIRED_MODULE = require(script.Parent._Index["nightcycle_midas@2.0.0"]["midas"])
export type Tracker = REQUIRED_MODULE.Tracker 
export type PrivateTracker = REQUIRED_MODULE.PrivateTracker 
export type TeleportDataEntry = REQUIRED_MODULE.TeleportDataEntry 
export type ConfigurationData = REQUIRED_MODULE.ConfigurationData 
export type Interface = REQUIRED_MODULE.Interface 
return REQUIRED_MODULE
