# signal
A typechecked branch of Quenty's signal class
