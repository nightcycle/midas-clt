return require(script.Parent.Parent["nightcycle_fetchu@1.0.1"]["fetchu"])
