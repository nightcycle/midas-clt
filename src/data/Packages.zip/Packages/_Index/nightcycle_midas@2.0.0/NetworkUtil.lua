return require(script.Parent.Parent["nightcycle_network-util@1.7.0"]["network-util"])
