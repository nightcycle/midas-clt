return require(script.Parent.Parent["nightcycle_service-proxy@1.0.0"]["service-proxy"])
