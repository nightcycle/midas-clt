Need help? Most of us do when we don't know something. Here is some resources to get help from us:

- [Devforum Post](https://devforum.roblox.com/t/fetchu-%E2%80%94-simplify-your-http-requests/1572093)
- [imacodr Discord Server](https://discord.gg/SYtrv9m)
